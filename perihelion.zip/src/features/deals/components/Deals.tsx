export default function Deals() {

  return (
    <>
    </>
  )
}