export interface Card {
  agent: object,
  client: object,
  property: object,
  body: string,
  interested: string,
  move_by: string
}