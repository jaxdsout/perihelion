export interface Option {
  property: object,
  list: object,
  price: string,
  unit_number: string,
  layout: string,
  sq_ft: string,
  available: string,
  notes: string,
}